package main

import (
	"fmt"
)

//var redisDb *redis.Client

//func initClient() (err error) {
//	redisDb = redis.NewClient(&redis.Options{
//		Addr:     "localhost:6379", //redis地址
//		Password: "",               //redis密码，没有则留空
//		DB:       0,                //默认数据库，默认是0
//	})
//	_, err = redisDb.Ping().Result()
//	if err != nil {
//		return err
//	}
//	return nil
//}

func main() {
	err := initClient()
	if err != nil {
		panic(err)
	}
	fmt.Println("Redis连接成功")

	//给数据库添加名称为key的string，并赋值为value.设置失效时间，0表示永久有效
	err = redisDb.Set("name1", "zhangsan", 0).Err()
	if err != nil {
		panic(err)
	}

	var val string
	//从数据库中拿数据
	val, err = redisDb.Get("name1").Result() //Result函数返回两个值，第一个是key的值，第二个是错误信息
	if err != nil {
		panic(err)
	}
	fmt.Println("name1的值：", val)

}
