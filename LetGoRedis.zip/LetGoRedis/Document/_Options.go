package Document

import "time"

type Options struct {
	//网络类型tcp或者unix
	//默认是tcp
	Network         string
	Addr            string            //redis地址，格式host:port
	OnConnect       func(*Conn) error //新建一个redis连接的时候，会回调这个函数
	Password        string            //redis密码，reids server没有设置可以为空
	DB              int               //redis数据库，序号从0开始，默认是0，可以不用设置
	MaxRetries      int               //redis操作失败最大重试次数，默认不重试
	MinRetryBackoff time.Duration     //最小重试时间间隔
	MaxRetryBackoff time.Duration     //最大重试时间间隔
	DialTimeout     time.Duration     //redis连接超时时间
	ReadTimeout     time.Duration     //socket读取超时时间，默认3秒
	WriteTimeout    time.Duration     //socket写超时时间
	PoolSize        int               //redis连接池的最大连接数。默认连接池大小等于cpu个数 * 10
	MinIdleConns    int               //redis连接池最小空闲连接数
	MaxConnAge      time.Duration     //redis连接最大的存活时间，默认不会关闭过时的连接
	PoolTimeout     time.Duration     //当你从redis连接池获取一个连接之后，连接池最多等待这个拿出去的连接多长时间
	//默认是等待ReadTimeout+1秒
	IdleTimeout time.Duration //redis连接池多久会关闭一个空闲连接
	//默认是5分钟，-1则表示关闭这个配置项
	IdleCheckFreequency time.Duration //多长时间检测一下，空闲连接
	//默认是1分钟，-1表示关闭空闲连接检测
	readOnly bool //只读设置，如果设置为true，redis只能查询缓存不能更新
}
