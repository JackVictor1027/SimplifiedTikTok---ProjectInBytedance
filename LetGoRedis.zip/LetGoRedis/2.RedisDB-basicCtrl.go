package main

//func main() {
//	//err := initClient()
//	//if err != nil { //redis连接错误
//	//	panic(err)
//	//}
//	//
//	////给数据库添加名称为key的string，并赋值为value.设置失效时间，0表示永久有效
//	//err = redisDb.Set("name1", "zhangsan", 0).Err()
//	//if err != nil {
//	//	panic(err)
//	//}
//	//
//	//var val string
//	////从数据库中拿数据
//	//val, err = redisDb.Get("name1").Result() //Result函数返回两个值，第一个是key的值，第二个是错误信息
//	//if err != nil {
//	//	panic(err)
//	//}
//	//fmt.Println("name1的值：", val)
//}
