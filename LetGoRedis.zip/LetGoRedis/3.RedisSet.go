package main

import (
	"fmt"
	"github.com/go-redis/redis"
)

var redisDb *redis.Client

func initClient() (err error) {
	redisDb = redis.NewClient(&redis.Options{
		Addr:     "localhost:6379", //redis地址
		Password: "",               //redis密码，没有则留空
		DB:       0,                //默认数据库，默认是0
	})
	_, err = redisDb.Ping().Result()
	if err != nil {
		return err
	}
	return nil
}
func main() {
	err := initClient()
	if err != nil {
		//redis连接错误
		panic(err)
	}
	//统计开发语言排行榜
	zsetKey := "language_rank"
	languages := []redis.Z{
		{Score: 90.0, Member: "Golang"},
		{Score: 98.0, Member: "Java"},
		{Score: 95.0, Member: "Python"},
		{Score: 97.0, Member: "JavaScript"},
		{Score: 92.0, Member: "C/C++"},
	}

	// 添加一个或者多个元素到集合，如果元素已经存在则更新分数
	num, err := redisDb.ZAdd(zsetKey, languages...).Result()
	if err != nil {
		fmt.Printf("zadd failed, err:%v\n", err)
		return
	}
	fmt.Printf("ZAdd添加成功 %d 元素\n", num)
	// 添加一个元素到集合
	redisDb.ZAdd(zsetKey, redis.Z{Score: 87, Member: "Vue"}).Err()

	//给元素Vue加上8分，最终vue得分95分
	redisDb.ZIncrBy(zsetKey, 8, "Vue")
	// 返回从0到-1位置的集合元素， 元素按分数从小到大排序 0到-1代表则返回全部数据
	values, err := redisDb.ZRange(zsetKey, 0, -1).Result()
	if err != nil {
		panic(err)
	}
	for _, val := range values {
		fmt.Println(val)
	}
	fmt.Println("-------------------------------\n")
	//仅当列表存在的时候才插入数据,此时列表不存在，无法插入
	redisDb.LPushX("studentList", "tom")

	//此时列表不存在，依然可以插入
	redisDb.LPush("studentList", "jack")

	//此时列表存在的时候才能插入数据
	redisDb.LPushX("studentList", "tom")

	// LPush支持一次插入任意个数据
	err = redisDb.LPush("studentList", "lily", "lilei", "zhangsan", "lisi").Err()
	if err != nil {
		panic(err)
	}
	// 返回从0开始到-1位置之间的数据，意思就是返回全部数据
	vals, err := redisDb.LRange("studentList", 0, -1).Result()
	if err != nil {
		panic(err)
	}
	fmt.Println(vals) //注意列表是有序的，输出结果是[lisi zhangsan lilei lily tom jack]

	var a int = 20

}
