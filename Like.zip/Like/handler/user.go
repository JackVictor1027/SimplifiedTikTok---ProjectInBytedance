package handler

import "github.com/gin-gonic/gin"

func LikeThisVideo(c *gin.Context) {

}
func GetLikelist(c *gin.Context) {

}

func GetLikes(c *gin.Context) {

}
func CancelLike(c *gin.Context) {

}

// GetUserInfo 获取用户信息
func GetUserInfo(c *gin.Context) {

}

// UpdateUserInfo 更新用户信息
func UpdateUserInfo(c *gin.Context) {

}

// DeleteUser 删除用户
func DeleteUser(c *gin.Context) {

}

// 添加用户
func AddUser(c *gin.Context) {

}
